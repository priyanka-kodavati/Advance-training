package corejava.problemstatement7.Deserialization;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
public class DeSerial {
	public static void main(String[] args) throws IOException {
		Product p=new Product(12,"Soap");
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		try{
			fos=new FileOutputStream("C:/Users/Admin/Desktop/file2.txt");
			oos=new ObjectOutputStream(fos);
			oos.writeObject(p);
			System.out.println("Serialization Done!!");
		}
		catch(IOException ioe){System.out.println("io");}
		finally{
			oos.close();
			fos.close();
		}
		Product e=null;
		try{
			FileInputStream fis=new FileInputStream("C:/Users/Admin/Desktop/file2.txt");
			ObjectInputStream ois=new ObjectInputStream(fis);
			e=(Product)ois.readObject();
			ois.close();
			fis.close();
		}
		catch(IOException ioe){ioe.printStackTrace(); return;}
		catch(ClassNotFoundException cnfe){
			System.out.println("Class is not found");
			cnfe.printStackTrace();
			return;
		}
		System.out.println("Employee id: "+e.getid());
		System.out.println("Employee project name: "+e.getproject_name());
	}
}
class Product implements java.io.Serializable{
	private int id;
	private String product_name;
	public Product(int id,String product_name) {
		this.id=id;
		this.product_name=product_name;
	}
	public int getid(){return id;}
	public void setid(int id){this.id=id;}
	public String getproject_name(){return product_name;}
	public void setproject_name(String product_name){this.product_name=product_name;}
}