package corejava.problemstatement1.rectangleprogram;
import java.util.Scanner;
class Rectangle {
	private int length;
	private int breadth;
	public Rectangle(int l,int b) {
		length=l;
		breadth=b;
	}
	public void Area() {
		int area = length * breadth;
		System.out.println("Area of the rectangle: " + area);
	}
	public void Display() {
		System.out.println("Length of the rectangle: " + length);
		System.out.println("Breadth of the rectangle: " + breadth);
	}
}
public class TestRectangle {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length of rectangle");
		int length =sc.nextInt();
		System.out.println("Enter the breadth of rectangle");
		int breadth =sc.nextInt();
		Rectangle obj1 = new Rectangle(length,breadth);
		obj1.Display();
		obj1.Area();
		System.out.println("======Second object======");
		Rectangle obj2 = new Rectangle(0,0);
		obj2.Display();
		obj2.Area();
	}
}
