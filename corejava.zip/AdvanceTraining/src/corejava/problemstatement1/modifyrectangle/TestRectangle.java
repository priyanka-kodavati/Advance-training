package corejava.problemstatement1.modifyrectangle;
import java.util.Scanner;

class TestRectangle {
    int length; 
    int breadth; 
    int area; 
    int perimeter;
    
    public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setWidth(int breadth) {
		this.breadth = breadth;
	}

	
    public TestRectangle()
    {
    	length = 1;
    	breadth= 1;
    }

    void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = in.nextInt();
    }
    
    void  areaRectangle()
    {
        area = length * breadth;
       
    }
 
     void  perimeterRectangle()
    {
    	 perimeter = 2*(length + breadth);
       
    }

    void display() {
    	if(length>0 && length<20)
        {
        System.out.println("Area of Rectangle = " + area);
        System.out.println("Perimeter of Rectangle = " +perimeter);}
       
        }

    public static void main(String args[]) {
    	
        TestRectangle obj1 = new TestRectangle();
        obj1.input();
        obj1.areaRectangle();
        obj1.perimeterRectangle();
        obj1.display();
        System.out.println("========Second object==========");
        TestRectangle obj2 = new TestRectangle();
        obj2.input();
        obj2.areaRectangle();
        obj2.perimeterRectangle();
        obj2.display();
        System.out.println("======third object========");
        TestRectangle obj3 = new TestRectangle();
        obj3.input();
        obj3.areaRectangle();
        obj3.perimeterRectangle();
        obj3.display();
        System.out.println("======fourth object=========");
        TestRectangle obj4 = new TestRectangle();
        obj4.input();
        obj4.areaRectangle();
        obj4.perimeterRectangle();
        obj4.display();
        System.out.println("=======fivth object========");
        TestRectangle obj5 = new TestRectangle();
        obj5.input();
        obj5.areaRectangle();
        obj5.perimeterRectangle();
        obj5.display();
    	
    }
}