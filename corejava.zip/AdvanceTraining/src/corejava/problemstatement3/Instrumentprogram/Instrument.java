package corejava.problemstatement3.Instrumentprogram;

public abstract class Instrument {
	public abstract void play();{
	}
}
