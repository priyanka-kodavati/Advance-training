package corejava.problemstatement2.Numbersprogram;
import java.util.Scanner;
public class Acceptnumbers {
	public static void main(String[] args) {

	    int i = 1, n = 13, firstTerm, secondTerm;
	    Scanner sc=new Scanner(System.in);
	    firstTerm=sc.nextInt();
	    secondTerm=sc.nextInt();
	    System.out.println("Fibonacci Series till " + n + " terms:");

	    while (i <= n) {
	      System.out.print(firstTerm + ", ");

	      int nextTerm = firstTerm + secondTerm;
	      firstTerm = secondTerm;
	      secondTerm = nextTerm;

	      i++;
	    }
	  }
}
